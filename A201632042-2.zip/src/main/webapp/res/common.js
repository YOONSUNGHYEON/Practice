$(function() {

	$("[data-url]").click(function() {
		var url = $(this).attr("data-url");
		location.href = url;
	})

	$("[data-confirm-delete]").click(function() {
		var url = "list2?departmentId="+$('#id').val();
		location.href = url;
	})


})

function list() {
	var url = "list2?departmentId="+$('#id').val();
	location.href = url;
}
