package net.skhu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import net.skhu.dto.Professor;
import net.skhu.mapper.DepartmentMapper;
import net.skhu.mapper.ProfessorMapper;
import net.skhu.mapper.StudentMapper;

@Controller
@RequestMapping("/c201632042")
public class ProfessorController {
	@Autowired StudentMapper studentMapper;
	@Autowired DepartmentMapper departmentMapper;
	@Autowired ProfessorMapper professorMapper;

	@RequestMapping("list1")
	public String test1(Model model) {
		List<Professor> professors = professorMapper.findAll();
		model.addAttribute("professors", professors);
		return "c201632042/list1";
	}

	@RequestMapping("edit")
	public String test2(Model model) {
		model.addAttribute("number", 123);
		return "c201632042/edit";
	}
}
