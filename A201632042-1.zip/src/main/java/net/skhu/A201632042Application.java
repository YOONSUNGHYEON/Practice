package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A201632042Application {

	public static void main(String[] args) {
		SpringApplication.run(A201632042Application.class, args);
	}
}
